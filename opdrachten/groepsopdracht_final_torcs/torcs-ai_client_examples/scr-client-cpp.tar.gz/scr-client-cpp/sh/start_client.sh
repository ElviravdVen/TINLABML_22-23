#!/usr/bin/env bash

date > logs/torcs_client.log; ./client >> logs/torcs_client.log