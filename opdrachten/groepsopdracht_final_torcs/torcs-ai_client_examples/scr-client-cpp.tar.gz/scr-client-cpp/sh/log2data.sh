#!/usr/bin/env bash

cat logs/torcs_client.log | grep ';' >> data/forza.csv